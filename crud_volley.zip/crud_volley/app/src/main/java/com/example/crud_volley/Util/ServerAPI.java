package com.example.crud_volley.Util;

/**
 * Created by Vian Azis.
 */

public class ServerAPI {
    public static final String URL_DATA = "http://192.168.43.29/Semester-4/Minggu_13/ci-3.1.11/Mahasiswa/Api";
    public static final String URL_INSERT = "http://192.168.43.29/Semester-4/Minggu_13/ci-3.1.11/Mahasiswa/ApiInsert";
    public static final String URL_DELETE = "http://192.168.43.29/Semester-4/Minggu_13/ci-3.1.11/Mahasiswa/ApiDelete";
    public static final String URL_UPDATE = "http://192.168.43.29/Semester-4/Minggu_13/ci-3.1.11/Mahasiswa/ApiUpdate";
}
